---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 神秘方块
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# 神秘方块

<BlockImage id="mysterious_cube" scale="8" />

还记得要找好几颗陨石才能集齐压印模板的岁月吗？这段岁月已然不再！现在陨石都会自带一个神秘方块。

不知道破坏（不带精准采集）的时候会发生什么事⋯⋯

也可以制造一个复制翻版⸺没那么神秘的方块。

## 配方

<RecipeFor id="not_so_mysterious_cube" />
